import 'dart:math' as math;
import 'package:flutter/material.dart';

const royalGold = Color(0xFFD6AE55);
const silkCream = LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFFFFAED), Color(0xFFF1E3C9), Color(0xFFFFF9ED), Color(0xFFF5E8CF)], stops: [0, .32, .62, 1]);
const silkWine = LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF451322), Color(0xFF83384C), Color(0xFF57182B), Color(0xFF773045)], stops: [0, .32, .67, 1]);
const silkGold = LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFFFE8A5), Color(0xFFBE8B2C), Color(0xFFFFE3A0), Color(0xFFC3943D)], stops: [0, .35, .65, 1]);

// Local vector silk: no network assets, animation loops or reading-page overlays.
class SilkSurface extends StatelessWidget {
  final Widget child;
  final bool wine;
  const SilkSurface({super.key, required this.child, this.wine = false});
  @override
  Widget build(BuildContext context) => DecoratedBox(
    decoration: BoxDecoration(gradient: wine ? silkWine : silkCream),
    child: CustomPaint(painter: _SilkWaves(wine), child: child),
  );
}
class _SilkWaves extends CustomPainter {
  final bool wine;
  const _SilkWaves(this.wine);
  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.clipRect(Offset.zero & size);
    for (var i = 0; i < 7; i++) {
      final y = size.height * (i / 6);
      final path = Path()..moveTo(0, y);
      for (var x = 0.0; x <= size.width + 4; x += 4) {
        path.lineTo(x, y + math.sin(x / math.max(size.width, 1) * 5 + i) * math.min(22, size.height * .1));
      }
      canvas.drawPath(path, Paint()..color = Colors.white.withValues(alpha: wine ? .045 : .15)..style = PaintingStyle.stroke..strokeWidth = 8);
    }
    canvas.restore();
  }
  @override
  bool shouldRepaint(covariant _SilkWaves oldDelegate) => oldDelegate.wine != wine;
}
class RoyalScaffold extends StatelessWidget {
  final PreferredSizeWidget? appBar;
  final Widget? body;
  const RoyalScaffold({super.key, this.appBar, this.body});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: appBar == null ? null : PreferredSize(
      preferredSize: appBar!.preferredSize,
      child: SilkSurface(wine: true, child: Theme(
        data: Theme.of(context).copyWith(appBarTheme: Theme.of(context).appBarTheme.copyWith(backgroundColor: Colors.transparent, surfaceTintColor: Colors.transparent, elevation: 0)),
        child: appBar!,
      )),
    ),
    body: SilkSurface(child: SizedBox.expand(child: body)),
  );
}
class RoyalButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final Widget child;
  const RoyalButton({super.key, required this.onPressed, required this.child});
  @override
  Widget build(BuildContext context) => Opacity(opacity: onPressed == null ? .45 : 1,
    child: Container(
      margin: const EdgeInsets.all(5),
      decoration: BoxDecoration(gradient: silkGold, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFFFEDBA)), boxShadow: const [BoxShadow(color: Color(0x55401320), offset: Offset(0, 3), blurRadius: 4)]),
      child: TextButton(onPressed: onPressed, style: TextButton.styleFrom(foregroundColor: const Color(0xFF491225), disabledForegroundColor: const Color(0xFF491225), minimumSize: const Size(48, 52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), child: child),
    ),
  );
}
