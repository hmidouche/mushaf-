import 'package:flutter/material.dart';
import 'royal_silk.dart';

class SurahEntry {
  final String name;
  final int page;
  const SurahEntry(this.name, this.page);
}

// Standard 604-page Madani pagination. Verify against the bundled scan on device.
const surahs = <SurahEntry>[
  SurahEntry('الفاتحة', 1), SurahEntry('البقرة', 2),
  SurahEntry('آل عمران', 50), SurahEntry('النساء', 77),
  SurahEntry('المائدة', 106), SurahEntry('الأنعام', 128),
  SurahEntry('الأعراف', 151), SurahEntry('الأنفال', 177),
  SurahEntry('التوبة', 187), SurahEntry('يونس', 208),
  SurahEntry('هود', 221), SurahEntry('يوسف', 235),
  SurahEntry('الرعد', 249), SurahEntry('إبراهيم', 255),
  SurahEntry('الحجر', 262), SurahEntry('النحل', 267),
  SurahEntry('الإسراء', 282), SurahEntry('الكهف', 293),
  SurahEntry('مريم', 305), SurahEntry('طه', 312),
  SurahEntry('الأنبياء', 322), SurahEntry('الحج', 332),
  SurahEntry('المؤمنون', 342), SurahEntry('النور', 350),
  SurahEntry('الفرقان', 359), SurahEntry('الشعراء', 367),
  SurahEntry('النمل', 377), SurahEntry('القصص', 385),
  SurahEntry('العنكبوت', 396), SurahEntry('الروم', 404),
  SurahEntry('لقمان', 411), SurahEntry('السجدة', 415),
  SurahEntry('الأحزاب', 418), SurahEntry('سبأ', 428),
  SurahEntry('فاطر', 434), SurahEntry('يس', 440),
  SurahEntry('الصافات', 446), SurahEntry('ص', 453),
  SurahEntry('الزمر', 458), SurahEntry('غافر', 467),
  SurahEntry('فصلت', 477), SurahEntry('الشورى', 483),
  SurahEntry('الزخرف', 489), SurahEntry('الدخان', 496),
  SurahEntry('الجاثية', 499), SurahEntry('الأحقاف', 502),
  SurahEntry('محمد', 507), SurahEntry('الفتح', 511),
  SurahEntry('الحجرات', 515), SurahEntry('ق', 518),
  SurahEntry('الذاريات', 520), SurahEntry('الطور', 523),
  SurahEntry('النجم', 526), SurahEntry('القمر', 528),
  SurahEntry('الرحمن', 531), SurahEntry('الواقعة', 534),
  SurahEntry('الحديد', 537), SurahEntry('المجادلة', 542),
  SurahEntry('الحشر', 545), SurahEntry('الممتحنة', 549),
  SurahEntry('الصف', 551), SurahEntry('الجمعة', 553),
  SurahEntry('المنافقون', 554), SurahEntry('التغابن', 556),
  SurahEntry('الطلاق', 558), SurahEntry('التحريم', 560),
  SurahEntry('الملك', 562), SurahEntry('القلم', 564),
  SurahEntry('الحاقة', 566), SurahEntry('المعارج', 568),
  SurahEntry('نوح', 570), SurahEntry('الجن', 572),
  SurahEntry('المزمل', 574), SurahEntry('المدثر', 575),
  SurahEntry('القيامة', 577), SurahEntry('الإنسان', 578),
  SurahEntry('المرسلات', 580), SurahEntry('النبأ', 582),
  SurahEntry('النازعات', 583), SurahEntry('عبس', 585),
  SurahEntry('التكوير', 586), SurahEntry('الانفطار', 587),
  SurahEntry('المطففين', 587), SurahEntry('الانشقاق', 589),
  SurahEntry('البروج', 590), SurahEntry('الطارق', 591),
  SurahEntry('الأعلى', 591), SurahEntry('الغاشية', 592),
  SurahEntry('الفجر', 593), SurahEntry('البلد', 594),
  SurahEntry('الشمس', 595), SurahEntry('الليل', 595),
  SurahEntry('الضحى', 596), SurahEntry('الشرح', 596),
  SurahEntry('التين', 597), SurahEntry('العلق', 597),
  SurahEntry('القدر', 598), SurahEntry('البينة', 598),
  SurahEntry('الزلزلة', 599), SurahEntry('العاديات', 599),
  SurahEntry('القارعة', 600), SurahEntry('التكاثر', 600),
  SurahEntry('العصر', 601), SurahEntry('الهمزة', 601),
  SurahEntry('الفيل', 601), SurahEntry('قريش', 602),
  SurahEntry('الماعون', 602), SurahEntry('الكوثر', 602),
  SurahEntry('الكافرون', 603), SurahEntry('النصر', 603),
  SurahEntry('المسد', 603), SurahEntry('الإخلاص', 604),
  SurahEntry('الفلق', 604), SurahEntry('الناس', 604),
];

class SurahIndexScreen extends StatelessWidget {
  const SurahIndexScreen({super.key});
  @override
  Widget build(BuildContext context) => RoyalScaffold(
    appBar: AppBar(title: const Text('فهرس السور')),
    body: ListView.separated(
      padding: const EdgeInsets.all(12),
      itemCount: surahs.length,
      separatorBuilder: (_, index) => const SizedBox(height: 9),
      itemBuilder: (context, index) {
        final surah = surahs[index];
        return Container(
          decoration: BoxDecoration(gradient: silkCream, borderRadius: BorderRadius.circular(16), border: Border.all(color: royalGold), boxShadow: const [BoxShadow(color: Color(0x22681F32), offset: Offset(0, 3), blurRadius: 5)]),
          child: ListTile(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          minVerticalPadding: 10,
          leading: CircleAvatar(
            backgroundColor: const Color(0xFF681F32),
            foregroundColor: const Color(0xFFFFF6E5),
            child: Text('${index + 1}'),
          ),
          title: Text('سورة ${surah.name}', style: const TextStyle(
            color: Color(0xFF681F32), fontSize: 20,
            fontWeight: FontWeight.w600,
          )),
          trailing: const Icon(Icons.chevron_left_rounded, color: Color(0xFF681F32)),
          onTap: () => Navigator.of(context).pop<int>(surah.page),
        ));
      },
    ),
  );
}
