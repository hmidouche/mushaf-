import 'dart:io';

// Run after flutter create, before building. Idempotent; preserves existing app setup.
void main() {
  final manifest = File('android/app/src/main/AndroidManifest.xml');
  if (!manifest.existsSync()) throw StateError('Android manifest not found');
  var xml = manifest.readAsStringSync();
  for (final permission in ['POST_NOTIFICATIONS', 'RECEIVE_BOOT_COMPLETED', 'SCHEDULE_EXACT_ALARM']) {
    final name = 'android.permission.$permission';
    if (!xml.contains('android:name="$name"')) {
      xml = xml.replaceFirst('<application', '<uses-permission android:name="$name"/>\n    <application');
    }
  }
  if (!xml.contains('com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver')) {
    xml = xml.replaceFirst('</application>', '''
      <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
      <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
        <intent-filter>
          <action android:name="android.intent.action.BOOT_COMPLETED"/>
          <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
          <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
          <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
        </intent-filter>
      </receiver>
    </application>''');
  }
  manifest.writeAsStringSync(xml);
  final kotlin = File('android/app/build.gradle.kts');
  final gradle = kotlin.existsSync() ? kotlin : File('android/app/build.gradle');
  if (!gradle.existsSync()) throw StateError('App Gradle file not found');
  final original = gradle.readAsStringSync();
  if (!original.contains('// MUSHAF_PRAYER_DESUGAR_V1')) {
    gradle.writeAsStringSync(kotlin.existsSync() ? '''

// MUSHAF_PRAYER_DESUGAR_V1
android {
    compileOptions {
        isCoreLibraryDesugaringEnabled = true
    }
}
dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
}
''' : '''

// MUSHAF_PRAYER_DESUGAR_V1
android {
    compileOptions {
        coreLibraryDesugaringEnabled true
    }
}
dependencies {
    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'
}
''', mode: FileMode.append);
  }
  final raw = Directory('android/app/src/main/res/raw')..createSync(recursive: true);
  final audio = File('notification_resources/adhan.mp3');
  if (!audio.existsSync() || audio.lengthSync() < 1000) throw StateError('Adhan audio missing');
  audio.copySync('${raw.path}/adhan.mp3');
  final drawable = Directory('android/app/src/main/res/drawable')..createSync(recursive: true);
  File('${drawable.path}/ic_prayer.xml').writeAsStringSync('''<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">
<path android:fillColor="#FFFFFFFF" android:pathData="M12,2 L12,5 C8,7 6,9 6,12 L6,21 L18,21 L18,12 C18,9 16,7 12,5 Z M2,9 L4,9 L4,21 L2,21 Z M20,9 L22,9 L22,21 L20,21 Z"/>
</vector>''');
  // These resources are looked up by name, not by a Java resource reference.
  // A separate keep file preserves any existing project keep rules.
  File('${raw.path}/mushaf_keep.xml').writeAsStringSync('''<resources xmlns:tools="http://schemas.android.com/tools" tools:keep="@drawable/ic_prayer,@raw/adhan" />''');
  stdout.writeln('Android prayer notifications configured.');
}
