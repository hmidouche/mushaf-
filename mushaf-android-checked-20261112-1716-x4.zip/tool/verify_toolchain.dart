import 'dart:convert';
import 'dart:io';

bool atLeast(String text, int major, int minor) {
  final match = RegExp(r'^(\d+)\.(\d+)').firstMatch(text);
  if (match == null) return false;
  final a = int.parse(match.group(1)!);
  final b = int.parse(match.group(2)!);
  return a > major || (a == major && b >= minor);
}
void main() {
  if (!atLeast(Platform.version, 3, 6)) {
    stderr.writeln('Dart 3.6 or newer is required. Found ${Platform.version}');
    exit(1);
  }
  final result = Process.runSync('flutter', ['--version', '--machine']);
  if (result.exitCode != 0) {
    stderr.write(result.stderr);
    exit(result.exitCode);
  }
  final metadata = jsonDecode(result.stdout.toString()) as Map<String, dynamic>;
  final version = metadata['frameworkVersion']?.toString() ?? '';
  if (!atLeast(version, 3, 29)) {
    stderr.writeln('Flutter 3.29 or newer is required. Found $version');
    exit(1);
  }
  stdout.writeln('MUSHAF_TOOLCHAIN_OK Flutter=$version Dart=${Platform.version}');
}
