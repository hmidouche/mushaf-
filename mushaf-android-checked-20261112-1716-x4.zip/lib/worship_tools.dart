import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:adhan_dart/adhan_dart.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:hijri/hijri_calendar.dart';

const prayerNames = ['الفجر', 'الشروق', 'الظهر', 'العصر', 'المغرب', 'العشاء'];

class PrayerAlerts {
  static final plugin = FlutterLocalNotificationsPlugin();
  static bool ready = false;
  static Future<void> initialize() async {
    if (ready) return;
    await plugin.initialize(const InitializationSettings(android: AndroidInitializationSettings('ic_prayer')));
    ready = true;
  }
  static AndroidFlutterLocalNotificationsPlugin? get android => plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
  static const details = NotificationDetails(android: AndroidNotificationDetails(
    'prayer_adhan_v1', 'الأذان ومواقيت الصلاة',
    channelDescription: 'صوت الأذان عند دخول وقت الصلاة',
    importance: Importance.max, priority: Priority.high,
    sound: RawResourceAndroidNotificationSound('adhan'),
    playSound: true, audioAttributesUsage: AudioAttributesUsage.alarm,
    category: AndroidNotificationCategory.alarm,
  ));
  static Future<void> enable(SharedPreferences prefs) async {
    await initialize();
    if (android == null) throw StateError('هذه النسخة من التنبيهات مخصصة لأندرويد.');
    await android!.requestNotificationsPermission();
    if (await android!.areNotificationsEnabled() != true) {
      throw StateError('لم يُسمح بإشعارات التطبيق. فعّلها من إعدادات الهاتف.');
    }
    await android!.requestExactAlarmsPermission();
    if (await android!.canScheduleExactNotifications() != true) {
      throw StateError('يلزم السماح بالمنبهات الدقيقة ثم الضغط على التفعيل مجددًا.');
    }
    await prefs.setBool('prayerAlertsEnabled', true);
    try { await refresh(prefs); }
    catch (_) { await disable(prefs); rethrow; }
  }
  static Future<void> disable(SharedPreferences prefs) async {
    await prefs.setBool('prayerAlertsEnabled', false);
    await initialize();
    await plugin.cancelAll();
    await prefs.remove('prayerAlertsUntil');
  }
  static Future<void> test() async {
    await initialize();
    await plugin.show(9000, 'تجربة صوت الأذان', 'يمكنك إيقاف الصوت من زر إيقاف التجربة.', details);
  }
  static Future<void> stopTest() => plugin.cancel(9000);
  static Future<void> refresh(SharedPreferences p) async {
    if (!(p.getBool('prayerAlertsEnabled') ?? false)) return;
    await initialize();
    if (await android?.areNotificationsEnabled() != true || await android?.canScheduleExactNotifications() != true) {
      throw StateError('تحقق من أذونات الإشعارات والمنبهات الدقيقة.');
    }
    await plugin.cancelAll();
    final now = DateTime.now().toUtc();
    final phoneZone = p.getBool('prayerFollowPhoneZone') ?? true;
    final offset = phoneZone ? DateTime.now().timeZoneOffset.inMinutes / 60 : (p.getDouble('prayerUtc') ?? 1);
    final cityDate = now.add(Duration(minutes: (offset * 60).round()));
    final params = CalculationMethodParameters.muslimWorldLeague();
    if (p.getBool('prayerCustomAngles') ?? false) {
      params.fajrAngle = p.getDouble('prayerFajrAngle') ?? 18;
      params.ishaAngle = p.getDouble('prayerIshaAngle') ?? 17;
    }
    var id = 1;
    DateTime? last;
    try {
      for (var day = 0; day < 30; day++) {
        final d = DateTime(cityDate.year, cityDate.month, cityDate.day + day);
        final t = PrayerTimes(coordinates: Coordinates(p.getDouble('prayerLat') ?? 36.7538, p.getDouble('prayerLon') ?? 3.0588), date: d, calculationParameters: params);
        final times = [t.fajr, t.sunrise, t.dhuhr, t.asr, t.maghrib, t.isha];
        for (final i in [0, 2, 3, 4, 5]) {
          if (!(p.getBool('prayerAlert$i') ?? true)) continue;
          final instant = times[i].toUtc().add(Duration(minutes: p.getInt('prayerAdjust$i') ?? 0));
          if (!instant.isAfter(now)) continue;
          await plugin.zonedSchedule(id++, 'حان وقت صلاة ${prayerNames[i]}', p.getString('prayerCity') ?? 'الجزائر',
            tz.TZDateTime.from(instant, tz.UTC), details, androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle);
          if (last == null || instant.isAfter(last)) last = instant;
        }
      }
      if (last != null) { await p.setString('prayerAlertsUntil', last.toIso8601String()); }
      else { await p.remove('prayerAlertsUntil'); }
    } catch (_) { await plugin.cancelAll(); await p.remove('prayerAlertsUntil'); rethrow; }
  }
}

class AlertSettingsScreen extends StatefulWidget {
  final SharedPreferences prefs;
  const AlertSettingsScreen({super.key, required this.prefs});
  @override
  State<AlertSettingsScreen> createState() => _AlertSettingsScreenState();
}
class _AlertSettingsScreenState extends State<AlertSettingsScreen> {
  bool busy = false;
  String message = '';
  Future<void> run(Future<void> Function() task) async {
    setState(() { busy = true; message = ''; });
    try { await task(); if (mounted) setState(() { message = 'تم حفظ الإعداد. اختبر الصوت على هاتفك.'; }); }
    catch (e) { if (mounted) setState(() { message = 'تعذّر الإكمال: $e'; }); }
    finally { if (mounted) setState(() { busy = false; }); }
  }
  @override
  Widget build(BuildContext context) {
    final p = widget.prefs;
    final enabled = p.getBool('prayerAlertsEnabled') ?? false;
    final end = DateTime.tryParse(p.getString('prayerAlertsUntil') ?? '');
    return Scaffold(appBar: AppBar(title: const Text('الأذان والتنبيهات')), body: ListView(padding: const EdgeInsets.all(16), children: [
      SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('تفعيل الأذان عند دخول الصلاة'), subtitle: const Text('يطلب إذن الإشعارات والمنبهات الدقيقة'), value: enabled, onChanged: busy ? null : (v) => run(() => v ? PrayerAlerts.enable(p) : PrayerAlerts.disable(p))),
      for (final i in [0, 2, 3, 4, 5]) CheckboxListTile(contentPadding: EdgeInsets.zero, title: Text(prayerNames[i]), value: p.getBool('prayerAlert$i') ?? true, onChanged: busy ? null : (v) => run(() async { await p.setBool('prayerAlert$i', v ?? false); await PrayerAlerts.refresh(p); })),
      FilledButton.icon(onPressed: busy || !enabled ? null : () => run(PrayerAlerts.test), icon: const Icon(Icons.volume_up), label: const Text('تجربة صوت الأذان')),
      TextButton(onPressed: busy ? null : () => run(PrayerAlerts.stopTest), child: const Text('إيقاف التجربة')),
      OutlinedButton(onPressed: busy || !enabled ? null : () => run(() => PrayerAlerts.refresh(p)), child: const Text('تجديد مواقيت التنبيهات')),
      if (busy) const LinearProgressIndicator(),
      if (message.isNotEmpty) Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Text(message)),
      if (end != null) Text('آخر تنبيه مجدول: ${end.toLocal()}'),
      if (enabled && (end == null || end.isBefore(DateTime.now()))) const Text('لا يوجد جدول تنبيهات ساري. اضغط تجديد المواقيت وراجع الأذونات.'),
      const SizedBox(height: 12),
      const Text('تُجدول الصلوات الخمس لمدة 30 يومًا، وتتجدد عند فتح التطبيق أو حفظ إعدادات المدينة. افتح التطبيق قبل انتهاء المدة وبعد السفر أو تغيير توقيت الهاتف. لا يُؤذّن عند الشروق.'),
      const SizedBox(height: 8),
      const Text('التنبيهات تستخدم صوت أذان مضمّنًا من AlAdhan. مستوى الصوت ومدة تشغيله يخضعان للهاتف وإعدادات قناة الإشعارات. قد يقيّد أندرويد الصوت أو التنبيهات بسبب الصامت أو توفير الطاقة أو الإيقاف القسري. لا تُعد تجربة التطبيق مفتوحًا إثباتًا للعمل وهو مغلق.'),
    ]));
  }
}

String hijriLabel(DateTime date, int adjustment) {
  try {
    final h = HijriCalendar.fromDate(date.add(Duration(days: adjustment)));
    return '${h.hDay} ${h.getLongMonthName()} ${h.hYear} هـ';
  } catch (_) { return 'التاريخ خارج نطاق التقويم الهجري المتاح'; }
}
class HijriCalendarScreen extends StatefulWidget {
  final SharedPreferences prefs;
  const HijriCalendarScreen({super.key, required this.prefs});
  @override
  State<HijriCalendarScreen> createState() => _HijriCalendarScreenState();
}
class _HijriCalendarScreenState extends State<HijriCalendarScreen> {
  late DateTime selected;
  late int adjustment;
  @override
  void initState() { super.initState(); selected = DateTime.now(); adjustment = widget.prefs.getInt('hijriAdjustment') ?? 0; }
  @override
  Widget build(BuildContext context) {
    final h = HijriCalendar.fromDate(selected.add(Duration(days: adjustment)));
    final converter = HijriCalendar();
    final first = converter.hijriToGregorian(h.hYear, h.hMonth, 1).subtract(Duration(days: adjustment));
    final leading = first.weekday % 7;
    return Scaffold(appBar: AppBar(title: const Text('التقويم الهجري')), body: ListView(padding: const EdgeInsets.all(12), children: [
      Text(hijriLabel(selected, adjustment), textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall),
      Text('${selected.year}/${selected.month}/${selected.day} م', textAlign: TextAlign.center),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        IconButton(tooltip: 'الشهر السابق', onPressed: () => setState(() { selected = first.subtract(const Duration(days: 1)); }), icon: const Icon(Icons.chevron_right)),
        Text('${h.getLongMonthName()} ${h.hYear}'),
        IconButton(tooltip: 'الشهر التالي', onPressed: () => setState(() { selected = first.add(Duration(days: h.lengthOfMonth)); }), icon: const Icon(Icons.chevron_left)),
      ]),
      const Row(children: [for (final name in ['أحد', 'إثن', 'ثلا', 'أرب', 'خمي', 'جمع', 'سبت']) Expanded(child: Center(child: Text(name)))]),
      GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: leading + h.lengthOfMonth, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7, mainAxisExtent: 48), itemBuilder: (context, index) {
        final day = index - leading + 1;
        if (day < 1) return const SizedBox.shrink();
        return TextButton(style: TextButton.styleFrom(backgroundColor: day == h.hDay ? const Color(0xFF681F32) : null, foregroundColor: day == h.hDay ? Colors.white : const Color(0xFF681F32)), onPressed: () => setState(() { selected = first.add(Duration(days: day - 1)); }), child: Text('$day'));
      }),
      TextButton(onPressed: () => setState(() { selected = DateTime.now(); }), child: const Text('العودة إلى اليوم')),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Text('تصحيح التاريخ: '),
        DropdownButton<int>(value: adjustment, items: [for (var i = -2; i <= 2; i++) DropdownMenuItem(value: i, child: Text('$i يوم'))], onChanged: (v) async { if (v == null) return; await widget.prefs.setInt('hijriAdjustment', v); if (mounted) setState(() { adjustment = v; }); }),
      ]),
      const Text('تقويم حسابي وفق أم القرى، وقد يختلف عن ثبوت الهلال والإعلان الرسمي في بلدك. التصحيح هنا للعرض فقط ولا يغيّر مواقيت الصلاة.'),
    ]));
  }
}
